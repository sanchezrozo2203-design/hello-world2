package com.example.miprimerproyecto;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Android elige automáticamente el layout (vertical/horizontal) y los textos
        // según la orientación, el tamaño de pantalla y el idioma del dispositivo.
        setContentView(R.layout.activity_main);

        Button enter = findViewById(R.id.btn_enter);
        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, R.string.msg_entering, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
